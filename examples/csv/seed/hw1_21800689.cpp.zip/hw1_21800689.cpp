/*
 * @file hw1_21800689.cpp
 * @date 2022-03-18
 * 알고리듬 분석 첫번째 과제
 * 문제 - Write a program that implements min-priority queue. (You should use heap
    data structure, otherwise you will not get any point for this homework. Also 
    element index should begin from 1, not 0.) Assume maximum heap size is 30. 
    Each element has two fields – name and score. ‘name’ consists of English 
    alphabet (at most 10 characters) and ‘score’ is float point number between 0.0 
    and 100.0, and ‘score’ is a key. In this homework you don’t need to check 
    validity of name (i.e. ‘name’ field consists of alphabet). When your program 
    starts, it repeatedly presents menu until user enters ‘Q’.
 * 참고자료 - 
    - URL - 
    1. https://seongjuk.tistory.com/entry/%EC%9E%90%EB%A3%8C%EA%B5%AC%EC%A1%B0-%ED%9E%99-Heap-CC-%EA%B5%AC%ED%98%84-%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98-%EC%B5%9C%EC%86%8C-%ED%9E%99-%EC%B5%9C%EB%8C%80-%ED%9E%99
    
    - another source -  
    1. 데이터 구조 - 김영섭교수님 - pset 13 heap.h / heap.cpp
 *  
 */

#include <iostream>
#include <cstdio>
#include <string>

using namespace std;

struct Heap{ // Heap 안에 있는 name과 score을 각각 포인터로 받아들이면서 할당 될 수 있게 구조를 만든다.
    string* name;
    float* score; 
    int N;

    Heap(int capa = 30){ // 포인터로 설정된 name과 score의 사이즈를 설정해준다. 그리고 N의 값도 설정해주어 잘못된 값을 갖지 않도록 초기화 시켜준다.
        name = (string *)malloc(capa * sizeof(string));
        score = (float *)malloc(capa * sizeof(float));
        N = 0;
    };
    ~Heap(){};
};

using heap = Heap *;

void insert(heap h, string name, float score);
void remove(heap h);
void print_heap(heap h);
bool empty(heap p);
void replace(heap p, int index, float new_key);

int main(){

    string st;
    float key;
    int ele;
    char c;
    heap h = new Heap; // heap을 선언한뒤 초기화를 해준다.


    do{
        cout << "******* MENU *******\n";
        cout << "I : Insert new element into queue.\n";
        cout << "D : Delete element with smallest key from queue.\n";
        cout << "C : Decrease key of element in queue.\n";
        cout << "P : Print out all elements in queue.\n";
        cout << "Q : Quit.\n" << endl;

        cout << "Choose menu: ";
        cin >> c;
        switch(c){
            case 'I':
                cout << "Enter name of element: ";
                cin >> st;
                cout << "Enter key value of element: ";
                cin >> key;
                if (key < 0.0 || key > 100.0){ // 범위를 넘어선 경우 알려주고 MENU를 다시 선택할 수 있도록 한다.
                    cout << "Out of range( 0.0 ~ 100.0 )\n" << endl;
                    break;
                }
                insert(h, st, key);
                cout << "New element [" << st << ", " << key  << "] is inserted.\n" << endl;
                break;
            
            case 'D':
                remove(h);
                break;
            
            case 'C':
                cout << "Enter index of element: ";
                cin >> ele;
                if (ele > h->N){
                    cout << "Out of range (heap size)\n" << endl;
                    break;
                }
                cout << "Enter new key value: ";
                cin >> key;
                if (key < 0.0 || key > 100.0){ // 범위를 넘어선 경우 알려주고 MENU를 다시 선택할 수 있도록 한다.
                    cout << "Out of range( 0.0 ~ 100.0 )\n" << endl;
                    break;
                }
                replace(h, ele, key);
                cout << endl;
                break;
            
            case 'P':
                print_heap(h);
                cout << endl;
                break;
            
            case 'Q':
                cout << "Thank you. Bye!" << endl;
                break;
        }
        
    }while(c != 'Q');

}

bool empty(heap h){
    return h == NULL || h->N == 0 ? true : false;
}

void insert(heap h, string name, float score){
    
    h->N +=1;
    h->name[h->N] = name;
    h->score[h->N] = score;

    int child = h->N;
    int parent = child/2;

    // parent가 0이 되기전까지 
    while(parent){
        if(h->score[parent] > h->score[child]){ // 부모가 자식보다 클 경우 바꾼다.
            float temp_score = h->score[parent];
            string temp_name = h->name[parent];
            h->score[parent] = h->score[child];
            h->name[parent] = h->name[child];
            h->score[child] = temp_score;
            h->name[child] = temp_name;

            child = parent;
            parent = child/2;
        }
        else{
            break;
        }
    }
}

void remove(heap h){
    if(empty(h)) return;

    cout << "[" << h->name[1] << ", " << h->score[1] << "] is deleted.\n" << endl;

    // 맨 마지막 데이터를 처음으로 옮기고 맨 마지막 node를 제거한다.
    h->score[1] = h->score[h->N];
    h->name[1] = h->name[h->N];
    h->N--;

    int me = 1;
    int child = 2;

    //자식이 존재할 경우
    while(child <= h->N){
        if (child + 1 <= h->N && h->score[child] > h->score[child+1]){//오른쪽 자식이 왼쪽 자식보다 작은 경우는 오른쪽 자식과 비교한다.
            child++;
        }

        if(h->score[me] > h->score[child]){
            float temp_score = h->score[me];
            string temp_name = h->name[me];
            h->score[me] = h->score[child];
            h->name[me] = h->name[child];
            h->score[child] = temp_score;
            h->name[child] = temp_name;

            me = child;
            child = me * 2;
        }
        else{
            break;
        }
    }
}

void print_heap(heap h){
    for(int i=1; i<=h->N; i++){
        cout << "[" << h->name[i] << ", " << h->score[i] << "] ";
    }
    cout << endl;

}

void replace(heap h, int index, float new_key){
    
    h->score[index] = new_key;

    int me = 1;
    int child = 2;
    
    // 자식이 있을 경우
    while(child <= h->N){
        if (child + 1 <= h->N && h->score[child] < h->score[child+1]){ //오른쪽 자식이 왼쪽 자식보다 작을 경우는 오른쪽 자식과 비교를 한다.
            child++;
        }

        if(h->score[me] > h->score[child]){ // 자식보다 클 경우는 자식과 값을 변경한다.
            float temp_score = h->score[me];
            string temp_name = h->name[me];
            h->score[me] = h->score[child];
            h->name[me] = h->name[child];
            h->score[child] = temp_score;
            h->name[child] = temp_name;

            me = child;
            child = me * 2;
        }
        else{
            break;
        }
    }
}