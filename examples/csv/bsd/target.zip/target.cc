#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "myhtml/api.h"

extern "C" int LLVMFuzzerTestOneInput(const uint8_t* Data, size_t size){

        char * data = reinterpret_cast<char*>(const_cast<uint8_t*>(Data));
        if(size < 6){
                return 0;
        }

	// Basic init
        myhtml_t * myhtml = myhtml_create();
	myhtml_init(myhtml, MyHTML_OPTIONS_DEFAULT, 1, 0);	// 0X00

	// Init tree
	myhtml_tree_t * tree = myhtml_tree_create();
	myhtml_tree_init(tree, myhtml);

	// Parsing HTML
	if(myhtml_parse(tree, MyENCODING_UTF_8, data, size) != MyHTML_STATUS_OK){
		perror("Parsing Error");
		exit(EXIT_FAILURE);
	}

	// Serialize tree to an output string
	// myhtml_serialization == myhtml_serialization_tree_buffer
	mycore_string_raw_t str_raw;
	mycore_string_raw_clean_all(&str_raw);

	if(myhtml_serialization_tree_buffer(myhtml_tree_get_document(tree), &str_raw)){
		perror("Serialization Error");
		exit(EXIT_FAILURE);
	}

	//release
	mycore_string_raw_destroy(&str_raw, false);
	myhtml_tree_destroy(tree);
        myhtml_destroy(myhtml);
        return 0;
}
