package others;

public class MtSub extends DefrdSub{
	String mtsub = "";
	
	public MtSub(){
		this.mtsub = "(mtSub)";
	}
	
	public String getASTCode() {
		return "(mtSub)";
	}
}

